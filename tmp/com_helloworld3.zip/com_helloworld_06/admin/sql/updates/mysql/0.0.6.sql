INSERT INTO `#__helloworld` (`greeting`) VALUES
	('helloworld 3!'),
	('helloworld 4!'),
	('helloworld 5!'),
	('helloworld 6!'),
	('helloworld 7!'),
	('helloworld 8!'),
	('helloworld 9!'),
	('helloworld 10!'),
	('helloworld 11!'),
	('helloworld 12!');
	