<?php

// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );

// import Joomla view library
jimport ( 'joomla.application.component.view' );

/**
 * helloworlds View
 */
class helloworldViewhelloworld extends JViewLegacy {
	/**
	 * helloworlds view display method
	 *
	 * @return void
	 */
	function display($tpl = null) {
		parent::display($tpl);
	}
}