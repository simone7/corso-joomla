<?php

// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted Access' );

?>
<h1>helloworld</h1>