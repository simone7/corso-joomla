<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controller library
jimport('joomla.application.component.controller');

/**
 * General Controller of helloworld component
 */
class helloworldController extends JControllerLegacy
{
	
}
